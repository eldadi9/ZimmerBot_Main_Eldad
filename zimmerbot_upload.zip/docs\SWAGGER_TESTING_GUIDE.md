# מדריך בדיקות ב-Swagger UI - שלב שלב

## פתיחת Swagger UI

1. פתח בדפדפן: `http://127.0.0.1:8000/docs`
2. תראה את כל ה-endpoints עם תיעוד מלא

---

## בדיקה 1: GET /health ✅

**איך לבדוק:**
1. לחץ על `GET /health`
2. לחץ על "Try it out"
3. לחץ על "Execute"
4. ✅ תוצאה צפויה: `200 OK` עם `"status": "healthy"`

---

## בדיקה 2: GET /cabins ✅

**איך לבדוק:**
1. לחץ על `GET /cabins`
2. לחץ על "Try it out"
3. לחץ על "Execute"
4. ✅ תוצאה צפויה: רשימת 3 צימרים

**📝 הערה חשובה:** שמור את ה-`cabin_id` מהתגובה! תצטרך אותו לבדיקות הבאות.

**דוגמה ל-cabin_id:**
- `ZB01` (מהצימר של יולי)
- `ZB02` (מהצימר של אמי)
- `ZB03` (מהצימר של מורן)

או UUID מהתגובה, למשל: `c5b7e7bd-2790-514a-97ef-6803e71579b2`

---

## בדיקה 3: POST /availability ⚠️

### איך למלא נכון:

1. לחץ על `POST /availability`
2. לחץ על "Try it out"
3. מלא את ה-JSON (העתק את זה בדיוק):

```json
{
  "check_in": "2026-02-15 15:00",
  "check_out": "2026-02-17 11:00",
  "adults": 2,
  "kids": null,
  "area": null,
  "features": null
}
```

**📝 פורמט תאריכים חשוב:**
- ✅ נכון: `"2026-02-15 15:00"` (YYYY-MM-DD HH:MM)
- ✅ נכון: `"2026-02-15"` (YYYY-MM-DD)
- ❌ שגוי: `"01/03/26"` (לא תקין!)
- ❌ שגוי: `"06/06/26g"` (יש "g" בסוף!)

**פרמטרים:**
- `check_in`: תאריך כניסה בפורמט `YYYY-MM-DD HH:MM` או `YYYY-MM-DD`
- `check_out`: תאריך יציאה בפורמט `YYYY-MM-DD HH:MM` או `YYYY-MM-DD`
- `adults`: מספר מבוגרים (מספר, לא מחרוזת!)
- `kids`: מספר ילדים (מספר או `null`)
- `area`: אזור (מחרוזת או `null`)
- `features`: רשימת features מופרדת בפסיקים (מחרוזת או `null`), למשל: `"jacuzzi,pool,bbq"`

4. לחץ על "Execute"
5. ✅ תוצאה צפויה: `200 OK` עם רשימת צימרים זמינים

**דוגמה לתגובה:**
```json
[
  {
    "cabin_id": "ZB01",
    "name": "הצימר של יולי",
    "area": "גליל מערבי",
    "nights": 2,
    "regular_nights": 1,
    "weekend_nights": 1,
    "total_price": 1500.0,
    "max_adults": 2,
    "max_kids": 2,
    "features": "jacuzzi,pool,accessible,bbq,pet_friendly"
  }
]
```

---

## בדיקה 4: POST /quote ⚠️

### איך למלא נכון:

1. **קודם כל, קבל cabin_id:**
   - הרץ `GET /cabins` (בדיקה 2)
   - העתק את ה-`cabin_id` מהתגובה (למשל: `ZB01` או UUID)

2. לחץ על `POST /quote`
3. לחץ על "Try it out"
4. מלא את ה-JSON (העתק את זה בדיוק):

```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-02-15 15:00",
  "check_out": "2026-02-17 11:00",
  "adults": 2,
  "kids": null,
  "addons": [
    {
      "name": "מסאג' לחדר",
      "price": 200
    },
    {
      "name": "ארוחת שף",
      "price": 300
    }
  ]
}
```

**📝 חשוב:**
- `cabin_id`: **חייב להיות תקין!** השתמש ב-`ZB01`, `ZB02`, או `ZB03` (או UUID מהתגובה של `/cabins`)
- `check_in` ו-`check_out`: **פורמט נכון!** `YYYY-MM-DD HH:MM` או `YYYY-MM-DD`
- `adults`: מספר (לא מחרוזת!)
- `kids`: מספר או `null` (לא מחרוזת!)
- `addons`: רשימה של אובייקטים, כל אחד עם `name` ו-`price`

**אם יש שגיאת 404:**
- `cabin_id` לא נכון
- פתרון: הרץ `GET /cabins` וקח `cabin_id` מהתגובה

**אם יש שגיאת 422:**
- בדוק את הפורמט של התאריכים
- בדוק ש-`adults` ו-`kids` הם מספרים (לא מחרוזות)
- בדוק ש-`addons` הוא רשימה תקינה

5. לחץ על "Execute"
6. ✅ תוצאה צפויה: `200 OK` עם breakdown מפורט

**דוגמה לתגובה:**
```json
{
  "cabin_id": "ZB01",
  "cabin_name": "הצימר של יולי",
  "check_in": "2026-02-15 15:00",
  "check_out": "2026-02-17 11:00",
  "nights": 2,
  "regular_nights": 1,
  "weekend_nights": 1,
  "holiday_nights": 0,
  "high_season_nights": 0,
  "base_total": 1500.0,
  "weekend_surcharge": 300.0,
  "holiday_surcharge": 0.0,
  "high_season_surcharge": 0.0,
  "addons_total": 500.0,
  "addons": [
    {"name": "מסאג' לחדר", "price": 200.0},
    {"name": "ארוחת שף", "price": 300.0}
  ],
  "subtotal": 2000.0,
  "discount": {
    "percent": 0.0,
    "amount": 0.0,
    "reason": null
  },
  "total": 2000.0,
  "breakdown": [
    {
      "date": "2026-02-15",
      "is_weekend": true,
      "is_holiday": false,
      "is_high_season": false,
      "price": 900.0
    },
    {
      "date": "2026-02-16",
      "is_weekend": false,
      "is_holiday": false,
      "is_high_season": false,
      "price": 600.0
    }
  ]
}
```

---

## בדיקה 5: POST /book ⚠️

**⚠️ אזהרה:** זה יוצר הזמנה אמיתית ב-DB וביומן!

**איך למלא נכון:**

1. לחץ על `POST /book`
2. לחץ על "Try it out"
3. מלא את ה-JSON:

```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-02-20 15:00",
  "check_out": "2026-02-22 11:00",
  "customer": "ישראל ישראלי",
  "email": "test@example.com",
  "phone": "050-1234567",
  "adults": 2,
  "kids": null,
  "addons": [
    {
      "name": "מסאג' לחדר",
      "price": 200
    }
  ]
}
```

**📝 חשוב:**
- `cabin_id`: חייב להיות תקין (ZB01, ZB02, או ZB03)
- `check_in` ו-`check_out`: פורמט נכון!
- `customer`: שם הלקוח (חובה!)
- `email`: אימייל (אופציונלי)
- `phone`: טלפון (אופציונלי)
- `adults`: מספר (לא מחרוזת!)
- `kids`: מספר או `null`
- `addons`: רשימה תקינה

4. לחץ על "Execute"
5. ✅ תוצאה צפויה: `200 OK` עם פרטי ההזמנה

---

## בדיקה 6: GET /admin/bookings

**איך לבדוק:**
1. לחץ על `GET /admin/bookings`
2. לחץ על "Try it out"
3. (אופציונלי) מלא פרמטרים:
   - `status`: "confirmed" (אופציונלי)
   - `limit`: 100
   - `offset`: 0
4. לחץ על "Execute"
5. ✅ תוצאה צפויה: `200 OK` עם רשימת הזמנות

---

## בדיקה 7: GET /admin/audit

**איך לבדוק:**
1. לחץ על `GET /admin/audit`
2. לחץ על "Try it out"
3. (אופציונלי) מלא פרמטרים:
   - `table_name`: "bookings" (אופציונלי)
   - `action`: "INSERT" (אופציונלי)
   - `limit`: 10
   - `offset`: 0
4. לחץ על "Execute"
5. ✅ תוצאה צפויה: `200 OK` עם רשימת לוגים

---

## טיפים חשובים

### 1. פורמט תאריכים
- ✅ נכון: `"2026-02-15 15:00"`
- ✅ נכון: `"2026-02-15"`
- ❌ שגוי: `"01/03/26"`
- ❌ שגוי: `"06/06/26g"`

### 2. מספרים vs מחרוזות
- ✅ נכון: `"adults": 2` (מספר)
- ❌ שגוי: `"adults": "2"` (מחרוזת)

### 3. null vs מחרוזת ריקה
- ✅ נכון: `"kids": null`
- ❌ שגוי: `"kids": ""`

### 4. cabin_id
- תמיד קבל את ה-`cabin_id` מהתגובה של `GET /cabins`
- אפשר להשתמש ב-`ZB01`, `ZB02`, `ZB03` (אם הם קיימים)
- או UUID מהתגובה

### 5. תוספות (addons)
- ✅ נכון: `[{"name": "מסאג' לחדר", "price": 200}]`
- ❌ שגוי: `["מסאג' לחדר"]`

---

## פתרון בעיות נפוצות

### שגיאת 400 ב-/availability
- **סיבה:** פורמט תאריך לא תקין
- **פתרון:** השתמש ב-`"YYYY-MM-DD HH:MM"` או `"YYYY-MM-DD"`

### שגיאת 404 ב-/quote
- **סיבה:** `cabin_id` לא נכון
- **פתרון:** הרץ `GET /cabins` וקח `cabin_id` מהתגובה

### שגיאת 422 ב-/quote
- **סיבה:** פורמט לא תקין של הפרמטרים
- **פתרון:** בדוק ש:
  - תאריכים בפורמט נכון
  - `adults` ו-`kids` הם מספרים (לא מחרוזות)
  - `addons` הוא רשימה תקינה

### שגיאת 500 ב-/admin/audit
- **סיבה:** עמודות חסרות בטבלה
- **פתרון:** הרץ את ה-migration או צור את הטבלאות מחדש

---

## סדר מומלץ לבדיקה

1. ✅ GET /health
2. ✅ GET /cabins (שמור את cabin_id!)
3. ✅ POST /availability
4. ✅ POST /quote (השתמש ב-cabin_id מהשלב 2)
5. ⚠️ POST /book (רק אם אתה רוצה ליצור הזמנה אמיתית)
6. ✅ GET /admin/bookings
7. ✅ GET /admin/audit

---

## דוגמאות JSON מוכנות

### POST /availability
```json
{
  "check_in": "2026-02-15 15:00",
  "check_out": "2026-02-17 11:00",
  "adults": 2,
  "kids": null,
  "area": null,
  "features": null
}
```

### POST /quote
```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-02-15 15:00",
  "check_out": "2026-02-17 11:00",
  "adults": 2,
  "kids": null,
  "addons": [
    {"name": "מסאג' לחדר", "price": 200},
    {"name": "ארוחת שף", "price": 300}
  ]
}
```

### POST /book
```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-02-20 15:00",
  "check_out": "2026-02-22 11:00",
  "customer": "ישראל ישראלי",
  "email": "test@example.com",
  "phone": "050-1234567",
  "adults": 2,
  "kids": null,
  "addons": [
    {"name": "מסאג' לחדר", "price": 200}
  ]
}
```

---

**🎯 טיפ אחרון:** תמיד התחל עם `GET /cabins` כדי לקבל את ה-`cabin_id` הנכון!

