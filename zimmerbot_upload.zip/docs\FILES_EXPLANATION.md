# 📚 הסבר מפורט על כל הקבצים בתיקיית `database/`

## 📋 קבצי בדיקה (Test Scripts)

### 1. `check_stage1.py`
**תפקיד:** בדיקת שלב 1 - מודל נתונים (Database Schema)
- **מה הוא בודק:**
  - קיום כל הטבלאות הנדרשות (cabins, customers, bookings, pricing_rules, transactions, notifications, audit_log)
  - קיום Foreign Keys (קשרים בין טבלאות)
  - קיום Indexes (מפתחות חיפוש)
  - Constraints (אילוצים)
  - יכולת CRUD (יצירה, קריאה, עדכון, מחיקה)
- **איך להריץ:** `python database/check_stage1.py`
- **מתי להשתמש:** אחרי יצירת מסד הנתונים והרצת `schema.sql`

### 2. `check_stage2.py`
**תפקיד:** בדיקת שלב 2 - חיבור ליומן Google Calendar ובדיקת זמינות
- **מה הוא בודק:**
  - חיבור ל-Google Calendar API
  - קריאת צימרים מ-Google Sheets
  - רשימת אירועים ביומן
  - יצירת אירוע חדש
  - בדיקת זמינות צימר
- **איך להריץ:** `python database/check_stage2.py`
- **מתי להשתמש:** אחרי הגדרת Google Calendar credentials

### 3. `check_stage3.py`
**תפקיד:** בדיקת שלב 3 - מנוע תמחור (Pricing Engine)
- **מה הוא בודק:**
  - חישוב מחיר בסיסי
  - חישוב מחיר סופ"ש
  - חישוב מחיר חג
  - חישוב מחיר עונה גבוהה
  - חישוב תוספות (addons)
  - הנחות
- **איך להריץ:** `python database/check_stage3.py`
- **מתי להשתמש:** אחרי התקנת `src/pricing.py`

### 4. `check_stage4.py`
**תפקיד:** בדיקת שלב 4 - מנגנון Hold (החזקת צימר)
- **מה הוא בודק:**
  - חיבור ל-Redis
  - יצירת Hold
  - שחרור Hold
  - המרת Hold להזמנה
  - מניעת הזמנה כפולה
- **איך להריץ:** `python database/check_stage4.py`
- **מתי להשתמש:** אחרי התקנת Redis והגדרת `src/hold.py`
- **הערה:** דורש Redis מותקן ופועל

### 5. `full_flow_test.py`
**תפקיד:** בדיקה מלאה end-to-end של כל התהליך
- **מה הוא בודק:**
  1. קריאה מ-Google Sheets
  2. ייבוא ל-DB
  3. קריאה מ-DB
  4. בדיקת זמינות
  5. יצירת Hold
  6. המרת Hold להזמנה
- **איך להריץ:** `python database/full_flow_test.py`
- **מתי להשתמש:** בדיקה סופית אחרי שכל השלבים עובדים

### 6. `test_api_endpoints.py`
**תפקיד:** בדיקת כל ה-API endpoints
- **מה הוא בודק:**
  - `/health` - בריאות השרת
  - `/cabins` - רשימת צימרים
  - `/availability` - בדיקת זמינות
  - `/quote` - הצעת מחיר
  - `/book` - יצירת הזמנה
  - `/admin/bookings` - רשימת הזמנות
  - `/admin/audit` - לוגים
- **איך להריץ:** `python database/test_api_endpoints.py`
- **מתי להשתמש:** אחרי שהשרת רץ (`run_api.bat`)
- **דרישה:** השרת צריך לרוץ על `http://127.0.0.1:8000`

### 7. `show_all_data.py`
**תפקיד:** הצגת כל הנתונים במסד הנתונים
- **מה הוא מציג:**
  - רשימת כל הצימרים
  - רשימת כל הלקוחות
  - רשימת כל ההזמנות
  - רשימת כל התשלומים
  - רשימת כל הלוגים
- **איך להריץ:** `python database/show_all_data.py`
- **מתי להשתמש:** לבדיקה מהירה של מה יש במסד הנתונים

---

## 📥 קבצי ייבוא (Import Scripts)

### 8. `import_cabins_to_db.py`
**תפקיד:** ייבוא צימרים מ-Google Sheets למסד הנתונים PostgreSQL
- **מה הוא עושה:**
  1. קורא צימרים מ-Google Sheets
  2. ממיר אותם לפורמט DB
  3. יוצר UUID דטרמיניסטי מ-cabin_id המקורי (ZB01, ZB02, וכו')
  4. שומר ב-`cabins` table
  5. מעדכן `cabin_id_string` עם ה-ID המקורי
- **איך להריץ:** `python database/import_cabins_to_db.py`
- **מתי להשתמש:** בפעם הראשונה או כשמעדכנים צימרים ב-Sheets
- **הערה:** אם הצימר כבר קיים (לפי UUID, calendar_id, או name), הוא יעודכן

### 9. `import_bookings_from_calendar.py`
**תפקיד:** ייבוא הזמנות קיימות מ-Google Calendar למסד הנתונים
- **מה הוא עושה:**
  1. קורא אירועים מכל יומני Google Calendar
  2. מפרסר את תיאור האירוע (description) לחילוץ פרטים
  3. יוצר לקוח חדש או מוצא קיים
  4. יוצר הזמנה חדשה ב-DB
  5. שומר `event_id` ו-`event_link`
- **איך להריץ:** `python database/import_bookings_from_calendar.py`
- **מתי להשתמש:** בפעם הראשונה כדי להעביר הזמנות קיימות מה-Calendar ל-DB
- **הערה:** מנסה לחלץ פרטים מתיאור האירוע (Cabin, Customer, Phone, וכו')

---

## 🔧 קבצי תיקון (Fix Scripts)

### 10. `fix_calendar_ids.py`
**תפקיד:** תיקון `calendar_id` ב-DB לפי Google Sheets
- **מה הוא עושה:**
  1. קורא צימרים מ-Google Sheets
  2. קורא צימרים מ-DB
  3. מתאים בין Sheets ל-DB לפי שם הצימר
  4. מעדכן `calendar_id` ב-DB לפי מה שיש ב-Sheets
- **איך להריץ:** `python database/fix_calendar_ids.py`
- **מתי להשתמש:** אם `calendar_id` ב-DB לא תואם ל-Sheets

---

## 🗄️ קבצי SQL (Database Schema)

### 11. `schema.sql`
**תפקיד:** יצירת כל הטבלאות במסד הנתונים
- **מה הוא מכיל:**
  - `cabins` - טבלת צימרים
  - `customers` - טבלת לקוחות
  - `bookings` - טבלת הזמנות
  - `quotes` - טבלת הצעות מחיר
  - `pricing_rules` - טבלת כללי תמחור
  - `transactions` - טבלת תשלומים
  - `notifications` - טבלת הודעות
  - `audit_log` - טבלת לוגים
  - Foreign Keys, Indexes, Constraints
- **איך להריץ:** `psql -U postgres -d zimmerbot_db -f database/schema.sql`
- **מתי להשתמש:** בפעם הראשונה או כשצריך ליצור מחדש את המסד

### 12. `schema_stage1.sql`
**תפקיד:** גרסה מוקדמת של schema (למטרות היסטוריות)
- **הערה:** לא בשימוש פעיל, נשמר למטרות גיבוי

### 13. `schema_stage1_fix_names.sql`
**תפקיד:** תיקון שמות טבלאות (למטרות היסטוריות)
- **הערה:** לא בשימוש פעיל, נשמר למטרות גיבוי

### 14. `add_cabin_id_string.sql`
**תפקיד:** הוספת עמודה `cabin_id_string` לטבלת `cabins`
- **מה הוא עושה:**
  - מוסיף עמודה `cabin_id_string VARCHAR(20)`
  - יוצר index על העמודה
- **איך להריץ:** `psql -U postgres -d zimmerbot_db -f database/add_cabin_id_string.sql`
- **מתי להשתמש:** אם העמודה לא קיימת (אבל `import_cabins_to_db.py` כבר עושה את זה)

### 15. `migration_add_event_fields.sql`
**תפקיד:** הוספת `event_id` ו-`event_link` לטבלת `bookings`
- **מה הוא עושה:**
  - מוסיף עמודות `event_id` ו-`event_link` ל-`bookings`
  - יוצר טבלת `quotes` אם לא קיימת
  - יוצר indexes
- **איך להריץ:** `psql -U postgres -d zimmerbot_db -f database/migration_add_event_fields.sql`
- **מתי להשתמש:** אם העמודות לא קיימות (אבל `run_migration.py` כבר עושה את זה)

---

## 🚀 קבצי הרצה (Run Scripts)

### 16. `run_migration.py`
**תפקיד:** הרצת migration להוספת `event_id` ו-`event_link`
- **מה הוא עושה:** כמו `migration_add_event_fields.sql` אבל דרך Python
- **איך להריץ:** `python database/run_migration.py`
- **מתי להשתמש:** אם צריך להריץ migration דרך Python

### 17. `run_check.bat` / `run_check.sh`
**תפקיד:** הרצת כל בדיקות השלבים (1-4)
- **מה הוא עושה:** מריץ `check_stage1.py`, `check_stage2.py`, `check_stage3.py`, `check_stage4.py`
- **איך להריץ:** Windows: `database\run_check.bat` | Linux/Mac: `bash database/run_check.sh`
- **מתי להשתמש:** בדיקה מלאה של כל השלבים

### 18. `run_check_stage2.bat` / `run_check_stage2.sh`
**תפקיד:** הרצת בדיקת שלב 2 בלבד
- **איך להריץ:** Windows: `database\run_check_stage2.bat` | Linux/Mac: `bash database/run_check_stage2.sh`

### 19. `run_check_stage3.bat` / `run_check_stage3.sh` / `run_check_stage3.ps1`
**תפקיד:** הרצת בדיקת שלב 3 בלבד
- **איך להריץ:** Windows: `database\run_check_stage3.bat` או `powershell database/run_check_stage3.ps1` | Linux/Mac: `bash database/run_check_stage3.sh`

### 20. `run_check_stage4.bat`
**תפקיד:** הרצת בדיקת שלב 4 בלבד
- **איך להריץ:** `database\run_check_stage4.bat`

### 21. `run_import_cabins.bat`
**תפקיד:** הרצת ייבוא צימרים
- **איך להריץ:** `database\run_import_cabins.bat`

### 22. `run_import_bookings.bat`
**תפקיד:** הרצת ייבוא הזמנות
- **איך להריץ:** `database\run_import_bookings.bat`

### 23. `run_fix_calendar_ids.bat`
**תפקיד:** הרצת תיקון calendar_id
- **איך להריץ:** `database\run_fix_calendar_ids.bat`

### 24. `run_test_api.bat`
**תפקיד:** הרצת בדיקת API endpoints
- **איך להריץ:** `database\run_test_api.bat`
- **דרישה:** השרת צריך לרוץ על `http://127.0.0.1:8000`

### 25. `fix_token_scopes.bat`
**תפקיד:** תיקון scopes של Google OAuth token
- **מה הוא עושה:** מוחק את `token_api.json` כדי לכפות re-authentication עם scopes חדשים
- **איך להריץ:** `database\fix_token_scopes.bat`
- **מתי להשתמש:** אם יש שגיאת permissions ב-Google API

---

## 📖 קבצי תיעוד

### 26. `DATABASE_README.md` (בתיקיית `docs/`)
**תפקיד:** מדריך בדיקה לשלב 1
- **מה הוא מכיל:** הוראות מפורטות איך לבדוק את שלב 1

---

## 🔍 סיכום - מתי להשתמש בכל קובץ

### בפעם הראשונה (Setup):
1. `schema.sql` - יצירת מסד הנתונים
2. `import_cabins_to_db.py` - ייבוא צימרים
3. `import_bookings_from_calendar.py` - ייבוא הזמנות קיימות
4. `check_stage1.py` - בדיקה שהכל עובד

### בדיקות תקופתיות:
- `test_api_endpoints.py` - בדיקת API
- `show_all_data.py` - הצגת נתונים
- `full_flow_test.py` - בדיקה מלאה

### תיקונים:
- `fix_calendar_ids.py` - אם calendar_id לא תואם
- `fix_token_scopes.bat` - אם יש בעיית permissions

### Migrations:
- `run_migration.py` - אם צריך להוסיף עמודות חדשות

---

## ⚠️ הערות חשובות

1. **סדר הרצה חשוב:**
   - קודם `schema.sql`
   - אחר כך `import_cabins_to_db.py`
   - אחר כך `import_bookings_from_calendar.py`

2. **דרישות:**
   - PostgreSQL מותקן ופועל
   - Google Calendar credentials מוגדרים
   - Redis (רק לשלב 4 - Hold)

3. **קבצי Batch:**
   - כל קבצי ה-`.bat` הם wrappers ל-Python scripts
   - הם פשוט קוראים ל-Python script המתאים
   - אפשר להריץ ישירות את ה-Python scripts

