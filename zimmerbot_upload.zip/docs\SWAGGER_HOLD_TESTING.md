# מדריך בדיקת Hold דרך Swagger - שלב אחר שלב

## 📋 הכנה

1. **פתח Swagger UI:**
   ```
   http://127.0.0.1:8000/docs
   ```

2. **ודא שהשרת רץ:**
   ```bash
   python -m uvicorn src.api_server:app --reload
   ```

---

## 🔍 שלב 0: בדיקת צימרים זמינים

### 1. פתח: `GET /cabins`

**לחץ:** "Try it out" → "Execute"

**מה צריך לראות:**
```json
[
  {
    "cabin_id": "...",
    "name": "הצימר של...",
    "cabin_id_string": "ZB01" או "ZN01" וכו'
  }
]
```

**📝 רשום לעצמך:**
- איזה `cabin_id_string` יש (ZB01, ZB02, ZN01, וכו')
- איזה `name` יש לכל צימר

**💡 חשוב:** השתמש ב-`cabin_id_string` (ZB01) ולא ב-UUID!

---

## 🔒 שלב 1: יצירת Hold

### 1. פתח: `POST /hold`

### 2. לחץ: "Try it out"

### 3. הזן JSON (החלף את הערכים):

```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-01-10 15:00",
  "check_out": "2026-01-12 11:00",
  "customer_name": "ישראל ישראלי - בדיקה"
}
```

**📝 הערות:**
- `cabin_id`: השתמש ב-`cabin_id_string` מהשלב הקודם (ZB01, ZB02, וכו')
- `check_in`: תאריך בעתיד (לפחות מחר)
- `check_out`: תאריך אחרי check_in
- `customer_name`: כל שם שתרצה

### 4. לחץ: "Execute"

### 5. מה צריך לקבל:

**✅ הצלחה (200):**
```json
{
  "hold_id": "abc-123-def-456",
  "cabin_id": "ZB01",
  "check_in": "2026-01-10 15:00",
  "check_out": "2026-01-12 11:00",
  "expires_at": "2026-01-10T15:15:00",
  "status": "active",
  "message": "Hold created successfully",
  "warning": null
}
```

**❌ שגיאה אפשרית:**
- `404`: "Cabin not found" → בדוק את `cabin_id` (השתמש ב-ZB01 ולא UUID)
- `409`: "Cabin is not available" → הצימר תפוס בתאריכים האלה
- `500`: שגיאת שרת → בדוק את הלוגים

### 6. 📝 רשום לעצמך:
- **`hold_id`** - תצטרך אותו לשלבים הבאים!

---

## 🔍 שלב 2: בדיקת סטטוס Hold

### 1. פתח: `GET /hold/{hold_id}`

### 2. לחץ: "Try it out"

### 3. הזן:
- `hold_id`: העתק את ה-`hold_id` מהשלב הקודם

### 4. לחץ: "Execute"

### 5. מה צריך לקבל:

**✅ הצלחה (200):**
```json
{
  "hold_id": "abc-123-def-456",
  "cabin_id": "ZB01",
  "check_in": "2026-01-10",
  "check_out": "2026-01-12",
  "expires_at": "2026-01-10T15:15:00",
  "status": "active",
  "customer_name": "ישראל ישראלי - בדיקה",
  "customer_id": null,
  "created_at": "2026-01-10T15:00:00"
}
```

**❌ שגיאה:**
- `404`: "Hold not found or expired" → Hold לא קיים או פג תוקף

### 6. ✅ בדוק:
- `status` = "active"
- `expires_at` = בעוד 15 דקות מהזמן הנוכחי
- `cabin_id` = הצימר שבחרת

---

## 🚫 שלב 3: מניעת Hold כפול

### 1. פתח שוב: `POST /hold`

### 2. לחץ: "Try it out"

### 3. הזן **אותו JSON** כמו בשלב 1:
```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-01-10 15:00",
  "check_out": "2026-01-12 11:00",
  "customer_name": "לקוח אחר - בדיקה"
}
```

**📝 חשוב:** אותם `cabin_id`, `check_in`, `check_out`!

### 4. לחץ: "Execute"

### 5. מה צריך לקבל:

**✅ הצלחה (כצפוי - שגיאה!):**
```json
{
  "detail": "Cabin ZB01 is already on hold until 2026-01-10T15:15:00"
}
```

**קוד סטטוס:** `400` או `409`

**💡 זה אומר:** המערכת מונעת Hold כפול! ✅

---

## 📅 שלב 4: המרה להזמנה (Convert Hold to Booking)

### 1. פתח: `POST /book`

### 2. לחץ: "Try it out"

### 3. הזן JSON (החלף את הערכים):

```json
{
  "cabin_id": "ZB01",
  "check_in": "2026-01-10 15:00",
  "check_out": "2026-01-12 11:00",
  "customer": "ישראל ישראלי - בדיקה",
  "phone": "050-1234567",
  "email": "test@example.com",
  "adults": 2,
  "kids": 0,
  "total_price": 1000.0,
  "hold_id": "abc-123-def-456",
  "notes": "בדיקה של שלב 4"
}
```

**📝 הערות:**
- `hold_id`: העתק את ה-`hold_id` מהשלב 1
- `cabin_id`, `check_in`, `check_out`: **חייבים להיות זהים** ל-Hold!
- `total_price`: כל סכום (1000.0)

### 4. לחץ: "Execute"

### 5. מה צריך לקבל:

**✅ הצלחה (200):**
```json
{
  "success": true,
  "cabin_id": "ZB01",
  "event_id": "calendar-event-id-here",
  "event_link": "https://calendar.google.com/calendar/event?eid=...",
  "message": "Booking created successfully"
}
```

### 6. ✅ בדוק:
- `success` = true
- `event_id` = קיים (מזהה אירוע ב-Calendar)
- `event_link` = קישור ל-Google Calendar

### 7. 🔍 בדוק שה-Hold נמחק:

**חזור לשלב 2** (`GET /hold/{hold_id}`) עם אותו `hold_id`:

**מה צריך לקבל:**
```json
{
  "detail": "Hold not found or expired"
}
```

**קוד סטטוס:** `404`

**💡 זה אומר:** Hold הומר להזמנה ונמחק! ✅

---

## 🗑️ שלב 5: ביטול Hold ידני

### 1. צור Hold חדש (כמו בשלב 1)

**📝 רשום את ה-`hold_id` החדש!**

### 2. פתח: `DELETE /hold/{hold_id}`

### 3. לחץ: "Try it out"

### 4. הזן:
- `hold_id`: העתק את ה-`hold_id` החדש

### 5. לחץ: "Execute"

### 6. מה צריך לקבל:

**✅ הצלחה (200):**
```json
{
  "success": true,
  "message": "Hold released successfully",
  "hold_id": "abc-123-def-456"
}
```

### 7. 🔍 בדוק שה-Hold נמחק:

**חזור לשלב 2** (`GET /hold/{hold_id}`):

**מה צריך לקבל:**
```json
{
  "detail": "Hold not found or expired"
}
```

**💡 זה אומר:** Hold בוטל בהצלחה! ✅

---

## 📊 איפה לראות את התוצאות?

### 1. Google Calendar

1. פתח: https://calendar.google.com
2. מצא את יומן הצימר (למשל: "Cabin ZB01 - הצימר של...")
3. חפש אירועים:
   - **Hold:** אירוע צהוב עם "🔒 HOLD | שם לקוח"
   - **הזמנה:** אירוע ירוק עם "הזמנה | שם לקוח"

### 2. Database

**פתח psql:**
```bash
psql -U postgres -d zimmerbot_db
```

**בדוק הזמנות:**
```sql
SELECT * FROM bookings ORDER BY created_at DESC LIMIT 5;
```

**בדוק לקוחות:**
```sql
SELECT * FROM customers ORDER BY created_at DESC LIMIT 5;
```

**בדוק Transactions:**
```sql
SELECT * FROM transactions ORDER BY created_at DESC LIMIT 5;
```

### 3. Redis (אם מותקן)

```bash
redis-cli

# רשימת כל ה-Holds
KEYS "hold:*"

# פרטי Hold
GET "hold:ZB01:2026-01-10:2026-01-12"

# כמה זמן נשאר (TTL)
TTL "hold:ZB01:2026-01-10:2026-01-12"
```

---

## ⏰ תזמון Hold (15 דקות)

### איך לבדוק Hold מתפוגג אוטומטית:

1. **צור Hold** (שלב 1)
2. **רשום את ה-`expires_at`**
3. **חכה 15 דקות** (או שנה `HOLD_DURATION_SECONDS` ב-`.env` ל-60 שניות לבדיקה מהירה)
4. **בדוק שוב** (`GET /hold/{hold_id}`)

**מה צריך לקבל אחרי 15 דקות:**
```json
{
  "detail": "Hold not found or expired"
}
```

**💡 זה אומר:** Hold התפוגג אוטומטית! ✅

---

## 🐛 פתרון בעיות

### שגיאה: "Cabin not found"

**סיבות אפשריות:**
- השתמשת ב-UUID במקום ב-`cabin_id_string` (ZB01)
- הצימר לא קיים במערכת

**פתרון:**
1. בדוק `GET /cabins` - איזה `cabin_id_string` יש
2. השתמש ב-`cabin_id_string` (ZB01, ZB02, וכו')

### שגיאה: "Cabin is not available"

**סיבות אפשריות:**
- הצימר תפוס בתאריכים האלה
- יש אירוע ב-Calendar בתאריכים האלה

**פתרון:**
1. בחר תאריכים אחרים
2. או בדוק ב-Calendar מה יש בתאריכים האלה

### Hold לא מתפוגג

**סיבות אפשריות:**
- Redis לא פעיל (Hold לא מוגן)
- TTL לא עובד

**פתרון:**
1. התקן והפעל Redis
2. בדוק `redis-cli TTL "hold:..."`

---

## ✅ סיכום - מה בדקנו?

- [x] יצירת Hold
- [x] בדיקת סטטוס Hold
- [x] מניעת Hold כפול
- [x] המרה להזמנה
- [x] ביטול Hold ידני
- [x] Hold מתפוגג אוטומטית (15 דקות)

**🎉 כל הבדיקות עברו? שלב 4 מוכן!**

